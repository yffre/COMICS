# coding:utf-8
import os
import sys
import csv
import networkx as nx
from numpy import *
import time
import math

reload(sys)
sys.setdefaultencoding('utf-8')


def Getfilepath(folder_path):
    print "Function Getfilepath Strat"
    final_file_pathlist = []
    for root, dirs, files in os.walk(folder_path):
        for f in files:
            final_file_pathlist.append(os.path.join(root, f))
    print "Function Getfilepath Finished"
    return final_file_pathlist


def adj_mat(G):
    author_index = G.nodes()
    n = len(author_index)
    adjacency_matrix = eye(n)
    i = 0
    print G.edges()
    while i < n:
        adjacency_matrix[i][i] = 0
        j = i + 1
        while j < n:
            if G.has_edge(author_index[i], author_index[j]) or G.has_edge(author_index[j], author_index[j]):
                k = 0
                while k < n and k != i and k != j:
                    if((author_index[k], author_index[j]) in G.edges() or (author_index[j], author_index[k]) in G.edges()) and ((author_index[k], author_index[i]) in G.edges() or (author_index[i], author_index[k]) in G.edges()):
                        print 'one edge found %d %d %d ' % (i, j, k)
                        print author_index[i], author_index[j], author_index[k]
                        adjacency_matrix[i][j] = adjacency_matrix[i][j] + 1
                        adjacency_matrix[j][i] = adjacency_matrix[j][i] + 1
                        print adjacency_matrix[i][j]
                    k += 1
            j += 1
        i += 1
    print adjacency_matrix
    return adjacency_matrix


def diag_mat(author_index, adj_mat):
    n = len(author_index)
    diag_matrix = eye(n)
    i = 0
    while i < n:
        diag_matrix[i][i] = 0
        j = 0
        while j < n:
            diag_matrix[i][i] = diag_matrix[i][i] + adj_mat[i][j]
            j += 1
        i += 1
    print diag_matrix
    return diag_matrix
# class node:
#     def __init__(self):
#         self.data = ''
#         self.ind = 0


def return_prex(arr):  # 排序后元素排序前的下标
    print arr.tolist()
    arr = arr.tolist()
    arr = arr[0]
    n = len(arr)
    i = 0
    arr_stru = []
    while i < n:
        a = []
        a.append(arr[i])
        a.append(i)
        arr_stru.append(a)
        i += 1
    i = 0
    print '结构体集合'
    print arr_stru
    while i < n:
        j = i + 1
        while j < n:
            if arr_stru[j][0].real < arr_stru[i][0].real:
                t = arr_stru[i]
                arr_stru[i] = arr_stru[j]
                arr_stru[j] = t
            j += 1
        i += 1
    i = 0
    arr1 = []
    while i < n:
        arr1.append(arr_stru[i][1])
        i += 1
    print 'the index after ordered!'
    print arr1
    return arr1


def motif_conduc(arr, m, adj_mat):
    n = len(arr)
    cut_s = 0
    i = 0
    while i < m:
        j = m
        while j < n:
            cut_s = cut_s + adj_mat[arr[i]][arr[j]]
            j += 1
        i += 1
    i = 0
    s1 = 0
    while i < m:
        q = i + 1
        while q < m:
            w = q + 1
            while w < m:
                if adj_mat[arr[i]][arr[q]] != 0 and adj_mat[arr[i]][arr[w]] != 0 and adj_mat[arr[q]][arr[w]] != 0:
                    s1 += 1
                w += 1
            q += 1
        i += 1
    s2 = 0
    j = m
    while j < n:
        q = j + 1
        while q < n:
            w = q + 1
            while w < n:
                if adj_mat[arr[j]][arr[q]] != 0 and adj_mat[arr[j]][arr[w]] != 0 and adj_mat[arr[q]][arr[w]] != 0:
                    s2 += 1
                w += 1
            q += 1
        j += 1
    s = s1
    if s2 < s1:
        s = s2
    if s == 0:
        s = 0.0001
    mot_con = cut_s / (2 * s)
    return mot_con


def find_one_cluster(G, adj_mat, diag_mat):
    # author_list = G.nodes()

    # lap_mat2 = diag_mat - adj_mat
    # lap_mat = diag_mat - adj_mat
    author_list = G.nodes()
    i = 0
    num = G.number_of_nodes()
    print num
    # while i < num:
    #     j = i
    #     while j < num:
    #         if i == j and diag_mat[i][j] != 0:
    #             lap_mat[i][j] = 1
    #         elif adj_mat[i][j] != 0 :
    #             lap_mat[i][j] = lap_mat[j][i] = -1/sqrt(diag_mat[i][i]*diag_mat[j][j])
    #         j = j+1
    #     i = i+1
    I = eye(num)
    b = 0
    while b < num:
        y = 0
        while y < num:
            I[b][y] = 0
            if diag_mat[b][y] != 0:
                I[b][y] = diag_mat[b][y]**(-1 / 2)
            y += 1
        b += 1
    I2 = eye(G.number_of_nodes())
    b = 0
    while b < num:
        y = 0
        while y < num:
            if b != y:
                I2[b][y] = 0
            y += 1
        b += 1
    print mat(I2)
    lap_mat2 = mat(I2) - mat(I) * mat(adj_mat) * mat(I)
    print 'lap_mat2'
    print lap_mat2
    eval, evec = linalg.eig(lap_mat2)
    print eval
    print evec
    n = 0
    min_index = n
    while n < len(eval):
        if eval[n].imag != 0:
            eval[n] = 0
        if eval[n] > 0 and eval[n] < eval[min_index]:
            min_index = n
        n += 1
    print 'min eval'
    print eval[min_index]
    # t = 0
    # while eval[t] != 0 and eval[t] > min_val:
    m = 0
    min_vec = []
    while m < len(eval):
        min_vec.append(evec[m, min_index])
        m += 1
    print 'min_vec'
    print min_vec
    re_order = mat(min_vec) * mat(I)  # 乘以特征向量后的矩阵
    print 'reorder matrix'
    print re_order
    arr_ind = return_prex(re_order)
    motif_con = []
    i = 1
    while i < len(arr_ind):
        motif_con.append(motif_conduc(arr_ind, i, adj_mat))
        i += 1
    j = 0
    print 'motif_cond'
    print motif_con
    min_index = j
    min_value = motif_con[j]
    while j < len(motif_con):
        if motif_con[j] < min_value:
            print motif_con[j]
            min_value = motif_con[j]
            min_index = j
        j += 1
    print 'min_value and min_index'
    print min_value, min_index
    one_cluster = []
    i = 0
    arr2 = []
    while i <= min_index:
        arr2.append(arr_ind[i])
        one_cluster.append(author_list[arr_ind[i]])
        i += 1
    print 'one cluster'
    print one_cluster
    return one_cluster


def SaveToCsvFile(filepath, cluster_dic):
    file = filepath + '2.csv'
    csvrow = []
    i = 0
    for key in cluster_dic.keys():
        clusterinfo = list()
        clusterinfo.append(i)
        i += 1
        clusterinfo.append(cluster_dic[key])
        csvrow.append(clusterinfo)
    with open(file, 'wb') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(csvrow)
    print "Function SaveToCsvFile Finished!"


if __name__ == '__main__':
    folder_path = r'E:\dataset\MC_data_process\clustering\3'
    filepath = r'E:\dataset\MC_data_process\clustered\3\\'
    final_file_pathlist = Getfilepath(folder_path)
    Info = {}
    i = 0
    for file in final_file_pathlist:
        strat = time.clock()
        print file
        G = nx.read_gml(file)
        print G.number_of_nodes()
        author_index = G.nodes()
        G_mat = adj_mat(G)
        G_diag_mat = diag_mat(author_index, G_mat)
        arr = find_one_cluster(G, G_mat, G_diag_mat)
        print arr
        # G_info.append(arr)
        Info[i] = arr
        i += 1
        print '\n\r'
        print '\n\r'
        print 'time:', time.clock() - strat
    SaveToCsvFile(filepath, Info)
