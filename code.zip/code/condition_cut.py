# coding=utf-8
import numpy as np
import networkx as nx
import time
import csv

__author__ = 'dllgdxlxl'


# 计算模块度
def module_score(comm, graph):
    # 边的个数
    edges = graph.edges()
    m = len(edges)
    # 每个节点的度
    du = graph.degree()
    # 通过节点对（同一个社区内的节点对）计算
    ret = 0.0
    for c in comm:
        for x in c:
            for y in c:
                # 边都是前小后大的
                # 不能交换x，y，因为都是循环变量
                if x <= y:
                    if (x, y) in edges:
                        aij = 1.0
                    else:
                        aij = 0.0
                else:
                    if (y, x) in edges:
                        aij = 1.0
                    else:
                        aij = 0
                tmp = aij - du[x] * du[y] * 1.0 / (2 * m)
                ret = ret + tmp
    ret = ret * 1.0 / (2 * m)
    return ret


# 输入
def init(file_path):
    print 'Build Graph Start'
    graph = nx.Graph()
    csv_reader = csv.reader(open(file_path))
    for row in csv_reader:
        for author1 in row:
            for author2 in row:
                if cmp(author1, author2) != 0:
                    graph.add_edge(author1, author2)
    print 'Build Graph End'
    return graph


def condition1(comm, graph):
    nodes = graph.nodes()
    edges = graph.edges()
    for Ck in comm:
        for i in Ck:
            left = 0
            right = 0
            for j in Ck:
                if (i, j) in edges or (j, i) in edges:
                    left = left + 1
            for j in nodes:
                if j not in Ck and ((i, j) in edges or (j, i) in edges):
                    right = right + 1
            if left <= right:
                return False
    return True


def condition2(comm, graph):
    edges = graph.edges()
    for Ck in comm:
        for Ct in comm:
            if cmp(sorted(Ck), sorted(Ct)) != 0:
                for i in Ck:
                    left = 0
                    right = 0
                    for j in Ck:
                        if (i, j) in edges or (j, i) in edges:
                            left = left + 1
                    for j in Ct:
                        if (i, j) in edges or (j, i) in edges:
                            right = right + 1
                    if left <= right:
                        return False
    return True


def condition3(comm, graph):
    nodes = graph.nodes()
    edges = graph.edges()
    for Ck in comm:
        left = 0
        right = 0
        for i in Ck:
            for j in Ck:
                if (i, j) in edges or (j, i) in edges:
                    left = left + 1
            for j in nodes:
                if j not in Ck and ((i, j) in edges or (j, i) in edges):
                    right = right + 1
        if left <= right:
            return False
    return True


def condition4(comm, graph):
    edges = graph.edges()
    for Ck in comm:
        for Ct in comm:
            if cmp(sorted(Ck), sorted(Ct)) != 0:
                left = 0
                right = 0
                for i in Ck:
                    for j in Ck:
                        if (i, j) in edges or (j, i) in edges:
                            left = left + 1
                    for j in Ct:
                        if (i, j) in edges or (j, i) in edges:
                            right = right + 1
                if left <= right:
                    return False
    return True


# 根据x选择执行条件
def condition(comm, graph, x):
    if x == 1:
        return condition1(comm, graph)
    elif x == 2:
        return condition2(comm, graph)
    elif x == 3:
        return condition4(comm, graph)
    elif x == 4:
        return condition4(comm, graph)
    else:
        return False


# 计算两个集合之间的差集
def get_reduce(c1, c):
    c1_c = list()
    for x in c1:
        if x not in c:
            c1_c.append(x)
    return c1_c


def community_part(graph, x_valid):
    comm = list()
    comm.append(list(graph.nodes()))
    du = graph.degree()
    edges = graph.edges()
    invalid = list()
    found = True
    while found:
        found = False
        for c1 in comm:
            # 查找c1中有效且度最小的节点
            v = None
            du_x = 99999999999999
            for x in c1:
                if x not in invalid and du[x] < du_x:
                    du_x = du[x]
                    v = x
            # 如果未找到这样的节点说明这个分组无法再分
            if v is None:
                continue
            # 如果找到一个root节点，则创建一个分组c，将v添加进去
            c = list()
            c.append(v)
            # 开始执行第三步添加邻居节点
            found4 = True
            while found4:
                found4 = False
                # 查找C的邻居节点，看是否能添加进C中
                found3 = True
                cc = c[0:]
                while found3:
                    found3 = False
                    c_c1 = get_reduce(c1, cc)
                    for x in c_c1:
                        for y in cc:
                            if (x, y) in edges or (y, x) in edges:
                                c_tmp = cc[0:]
                                c_tmp.append(x)
                                if condition([c_tmp, get_reduce(c1, c_tmp)], graph, x_valid):
                                    cc = c_tmp
                                    found3 = True
                                    break
                        if found3:
                            break

                # 如果没有找到满足条件的的邻居节点，就执行第四步
                if len(cc) == len(c):
                    internal_du = {x: 0 for x in c1}
                    for x in c1:
                        for y in c1:
                            if (x, y) in edges:
                                internal_du[x] = internal_du[x] + 1
                                internal_du[y] = internal_du[y] + 1
                    # 查找最小的内度和外度之差
                    tmp_v = None
                    tmp_value = 99999999999
                    for x in c1:
                        if x not in c and abs(du[x] - internal_du[x] * 2) < tmp_value:
                            tmp_v = x
                            tmp_value = abs(du[x] - internal_du[x] * 2)
                    if not (tmp_v is None):
                        c.append(tmp_v)
                        found4 = True
                else:
                    c = cc
                    # 执行第五步
                    if len(c1) == len(c):
                        invalid.append(v)
                    else:
                        comm.remove(c1)
                        comm.append(c)
                        c1_c = get_reduce(c1, c)
                        comm.append(c1_c)
                        found = True
            if found:
                break
    return comm


def community_merge(comm, graph):
    while True:
        q2 = module_score(comm, graph)
        comm2 = None
        for c1 in comm:
            for c2 in comm:
                if cmp(sorted(c1), sorted(c2)) != 0:
                    comm1 = comm[0:]
                    comm1.remove(c1)
                    comm1.remove(c2)
                    comm1.append(c1 + c2)
                    q1 = module_score(comm1, graph)
                    if q1 > q2:
                        comm2 = comm1
                        break
            if comm2 is not None:
                comm = comm2
                break
        if comm2 is None:
            break
    return comm


def save_graph(comm, graph, file_path):
    i = 1
    for c in comm:
        sub_graph = graph.subgraph(c)
        name = file_path + 'graph' + str(i) + '.gml'
        nx.write_gml(sub_graph, name)
        i = i + 1


def main():
    graph = init(r'I:/data/DMAA/five_years_authors.csv')
    nx.write_gml(graph, r'I:/data/DMAA/graph/graph_whole.gml')
    for x in range(1, 5):
        print 'Community Partition (Condition '+str(x)+') Begin'
        comm = community_part(graph, x)
        print 'Community Partition (Condition '+str(x)+') End Result: ', len(comm)
        print 'Community Merge (Condition '+str(x)+') Begin'
        comm = community_merge(comm, graph)
        print 'Community Merge (Condition '+str(x)+') End Result:', len(comm)
        file_path = r'I:/data/DMAA/graph_condition' + str(x) + r'/'
        save_graph(comm, graph, file_path)


if __name__ == '__main__':
    print 'Author: ' + __author__
    print 'Start at ' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    main()
    print 'End at ' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
