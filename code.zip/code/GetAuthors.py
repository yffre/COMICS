# coding:utf-8
import json
import os
import csv
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


# aps-dataset-metadata-2013
# with open('','r') as jsonfile
def GetAllJsonPath(folder_path):
    '''get all json files' path and return a list'''
    print 'Function GetAllJsonPath Start'
    final_file_path_list = []
    for root, dirs, files in os.walk(folder_path):
        for f in files:
            final_file_path_list.append(os.path.join(root, f))
    print 'Function GetAllJsonPath Finished'
    return final_file_path_list


def GetJsonInfo(file_path_list,year_num):
    print "Function GetJsonInfo Start"
    doi_author = {}
    for file_path in file_path_list:
        f = open(file_path, 'r')
        json_data = json.load(f)  #
        f.close()
        doi = json_data['id'].encode('utf-8')
        year = json_data['rights']['copyrightYear']
        if year >= year_num:
            author_list = []
            try:
                author_dic_list = json_data['authors']
                for i in range(0, len(author_dic_list)):
                    author_dic = author_dic_list[i]
                    author_list.append(author_dic['name'].encode('utf-8').replace("\n", " "))
            except KeyError:
                print 'no author'
            doi_author[doi] = author_list  # 没有把缺少作者信息的去掉

    # doi_list.append(doi)
    # doi_list.append(date[0])
    print "Function getFullInfoDoiList end"
    return doi_author


def SaveToCSVFile(doi_author):
    print "Function SaveToCSVFile Start"
    
    csv_row = []
    for doi in doi_author:
        doi_list = list()
        doi_list.append(doi)
        doi_list = doi_author[doi]
        csv_row.append(doi_list)
    with open(r'H:\five_years_authors.csv', "wb") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(csv_row)
    print "Function SaveToCSVFile finished"


if __name__ == '__main__':
    folder_path = r'H:/share/aps/aps-dataset-metadata-2014'
    file_path_list = GetAllJsonPath(folder_path)
    doi_author = GetJsonInfo(file_path_list, 2009)
    SaveToCSVFile(doi_author)