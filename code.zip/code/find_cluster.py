# coding:utf-8
import json
import os
import csv
import sys
import networkx as nx
import matplotlib.pyplot as plt
import graph_made
import GetAuthors
import datetime
from numpy import *
import math

reload(sys)
sys.setdefaultencoding('utf-8')


def adj_mat(G, author_index):
    n = len(author_index)
    # print author_index[0],author_index[1]
    adjacency_matrix = eye(n)
    i = 0
    print G.edges()
    while i < n:
        adjacency_matrix[i][i] = 0
        j = i + 1
        while j < n:
            if (author_index[i], author_index[j]) in G.edges() or (author_index[j], author_index[i]) in G.edges():
                k = 0
                while k < n and k != i and k != j:
                    if((author_index[k], author_index[j]) in G.edges() or (author_index[j], author_index[k]) in G.edges()) and ((author_index[k], author_index[i]) in G.edges() or (author_index[i], author_index[k]) in G.edges()):
                        print 'one edge found %d %d %d ' % (i, j, k)
                        print author_index[i], author_index[j], author_index[k]
                        adjacency_matrix[i][j] = adjacency_matrix[i][j] + 1
                        adjacency_matrix[j][i] = adjacency_matrix[j][i] + 1
                        print adjacency_matrix[i][j]
                    k += 1
            j += 1
        i += 1
    print adjacency_matrix
    return adjacency_matrix


def diag_mat(author_index, adj_mat):
    n = len(author_index)
    diag_matrix = eye(n)
    i = 0
    while i < n:
        diag_matrix[i][i] = 0
        j = 0
        while j < n:
            diag_matrix[i][i] = diag_matrix[i][i] + adj_mat[i][j]
            j += 1
        i += 1
    print diag_matrix
    return diag_matrix
# class node:
#     def __init__(self):
#         self.data = ''
#         self.ind = 0


def return_prex(arr):  # 排序后元素排序前的下标
    print arr.tolist()
    arr = arr.tolist()
    arr = arr[0]
    n = len(arr)
    i = 0
    arr_stru = []
    while i < n:
        a = []
        a.append(arr[i])
        a.append(i)
        arr_stru.append(a)
        i += 1
    i = 0
    print '结构体集合'
    print arr_stru
    while i < n:
        j = i + 1
        while j < n:
            if arr_stru[j][0].real < arr_stru[i][0].real:
                t = arr_stru[i]
                arr_stru[i] = arr_stru[j]
                arr_stru[j] = t
            j += 1
        i += 1
    i = 0
    arr1 = []
    while i < n:
        arr1.append(arr_stru[i][1])
        i += 1
    print 'the index after ordered!'
    print arr1
    return arr1


def motif_conduc(arr, m, adj_mat):
    n = len(arr)
    cut_s = 0
    i = 0
    while i < m:
        j = m
        while j < n:
            cut_s = cut_s + adj_mat[arr[i]][arr[j]]
            j += 1
        i += 1
    i = 0
    s1 = 0
    while i < m:
        q = i + 1
        while q < m:
            w = q + 1
            while w < m:
                if adj_mat[arr[i]][arr[q]] != 0 and adj_mat[arr[i]][arr[w]] != 0 and adj_mat[arr[q]][arr[w]] != 0:
                    s1 += 1
                w += 1
            q += 1
        i += 1
    s2 = 0
    j = m
    while j < n:
        q = j + 1
        while q < n:
            w = q + 1
            while w < n:
                if adj_mat[arr[j]][arr[q]] != 0 and adj_mat[arr[j]][arr[w]] != 0 and adj_mat[arr[q]][arr[w]] != 0:
                    s2 += 1
                w += 1
            q += 1
        j += 1
    s = s1
    if s2 < s1:
        s = s2
    if s == 0:
        s = 0.0001
    mot_con = cut_s / (2 * s)
    return mot_con


def find_one_cluster(G, adj_mat, diag_mat, author_list):

    #lap_mat2 = diag_mat - adj_mat
    #lap_mat = diag_mat - adj_mat
    i = 0
    num = G.number_of_nodes()
    print num
    # while i < num:
    #     j = i
    #     while j < num:
    #         if i == j and diag_mat[i][j] != 0:
    #             lap_mat[i][j] = 1
    #         elif adj_mat[i][j] != 0 :
    #             lap_mat[i][j] = lap_mat[j][i] = -1/sqrt(diag_mat[i][i]*diag_mat[j][j])
    #         j = j+1
    #     i = i+1
    I = eye(num)
    b = 0
    while b < num:
        y = 0
        while y < num:
            I[b][y] = 0
            if diag_mat[b][y] != 0:
                I[b][y] = diag_mat[b][y]**(-1 / 2)
            y += 1
        b += 1
    I2 = eye(G.number_of_nodes())
    b = 0
    while b < num:
        y = 0
        while y < num:
            if b != y:
                I2[b][y] = 0
            y += 1
        b += 1
    print mat(I2)
    lap_mat2 = mat(I2) - mat(I) * mat(adj_mat) * mat(I)
    print 'lap_mat2'
    print lap_mat2
    eval, evec = linalg.eig(lap_mat2)
    print eval
    print evec
    n = 0
    min_index = n
    while n < len(eval):
        if eval[n].imag != 0:
            eval[n] = 0
        if eval[n] > 0 and eval[n] < eval[min_index]:
            min_index = n
        n += 1
    print 'min eval'
    print eval[min_index]
    #t = 0
    # while eval[t] != 0 and eval[t] > min_val:
    m = 0
    min_vec = []
    while m < len(eval):
        min_vec.append(evec[m, min_index])
        m += 1
    print 'min_vec'
    print min_vec
    re_order = mat(min_vec) * mat(I)  # 乘以特征向量后的矩阵
    print 'reorder matrix'
    print re_order
    arr_ind = return_prex(re_order)
    motif_con = []
    i = 1
    while i < len(arr_ind):
        motif_con.append(motif_conduc(arr_ind, i, adj_mat))
        i += 1
    j = 0
    print 'motif_cond'
    print motif_con
    min_index = j
    min_value = motif_con[j]
    while j < len(motif_con):
        if motif_con[j] < min_value:
            print motif_con[j]
            min_value = motif_con[j]
            min_index = j
        j += 1
    print 'min_value and min_index'
    print min_value, min_index
    one_cluster = []
    i = 0
    arr2 = []
    while i <= min_index:
        arr2.append(arr_ind[i])
        one_cluster.append(author_list[arr_ind[i]])
        i += 1
    print 'one cluster'
    print one_cluster
    return arr2


def co_standard(G, arr, author_list):
    n = len(arr)
    co_times = []
    i = 0
    temp = 0
    while i < n:
        k = arr[i]
        j = 0
        while j < n and j != i:
            if (author_list[k], author_list[arr[j]]) in G.edges() or (author_list[arr[j]], author_list[k]) in G.edges():
                temp += 1
            j += 1
        co_times.append(temp)
        i += 1
    m = len(co_times)
    i = 0
    sum = 0
    while i < m:
        sum += co_times[i]
        i += 1
    ave = sum / m
    i = 0
    sum1 = 0
    while i < m:
        sum1 = (co_times[i] - ave)**2
        i += 1
    co_val = sum1 / m
    return co_val


def qtt(file, arr, author_list):
    num = [0] * len(arr)
    with open(file, "rb") as csvfile:
        reader = csv.reader(csvfile)
        for line in reader:
            i = 0
            while i < len(arr):
                if author_list[arr[i]] in line:
                    num[i] += 1
                i += 1
    sum = 0
    j = 0
    while j < len(arr):
        sum += num[j]
        j += 1
    ave = sum / len(arr)
    sum1 = 0
    j = 0
    while j < len(arr):
        sum1 += (num[j] - ave)**2
        j += 1
    qtt_ave = sum1 / len(arr)
    return sum


def prim_vari(diag_mat, arr):
    n = len(arr)
    sum = 0
    i = 0
    while i < n:
        sum += diag_mat[arr[i]][arr[i]]
        i += 1
    ave = sum / n
    j = 0
    sum1 = 0
    while j < n:
        sum1 = (diag_mat[arr[j]][arr[j]] - ave)**2
        j += 1
    val_pri = sum1 / n
    return val_pri


def hindex(file, arr, author_list):
    print "hdindex"
    n = len(arr)
    num = [0] * n
    qto = [] * n
    for q in qto:
        q = []
    with open(file, "rb") as csvfile:
        reader = csv.reader(csvfile)
        # column = [row[6] for row in reader]
        # for i in column:
        #     csv_row.append(i)
        for line in reader:
            doi_list = []
            if line[6] != ''and line[7] != '':
                i = 0
                line6 = eval(line[6])
                line7 = eval(line[7])
                while i < n:
                    if author_list[arr[i]] in line6:
                        qto[i].append(len(line7))
                    i += 1
    i = 0
    while i < n:
        j = 0
        if len(qto) != 0:
            while j < len(qto[i]):
                k = j + 1
                while k < len(qto[i]):
                    if qto[i][k] > qto[i][j]:
                        t = qto[i][k]
                        qto[i][k] = qto[i][j]
                        qto[i][j] = t
                    k += 1
                j += 1
            m = 0
            while m < len(qto[i]):
                if m > qto[i][m]:
                    num[i] = m - 1
                    m = len(qto[i])
                m += 1
        i += 1
    i = 0
    sum = 0
    while i < n:
        sum += num[i]
        i += 1
    hindex_val = sum / n
    return hindex_val

if __name__ == '__main__':
    time1 = datetime.datetime.now()
    folder_path = r'D:\aps\all_information.csv'
    # folder_path = r'D:\aps\aps-dataset-metadata-20131'
    # file_path_list = GetAuthors.GetAllJsonPath(folder_path)
    # doi_author = GetAuthors.GetJsonInfo(file_path_list)
    # GetAuthors.SaveToCSVFile(doi_author)
    graph_made.get_auth_co(folder_path)
    G = nx.Graph()
    author_list1 = graph_made.GetAuthors(r'D:\aps\allauthors.csv')
    G = graph_made.MakeGraph(G, r'D:\aps\allauthors.csv', author_list1)
    pos = nx.random_layout(G)
    colors = ['r', 'g', 'b', 'c', 'm', 'y']
    g_num = 0
    csv_row = []
    sum_value = 0
    for g in nx.connected_component_subgraphs(G):
        sum_value1 = 0
        author_list = []
        for name in g.nodes():
            author_list.append(name)
        nd_colors = ['k'] * g.number_of_nodes()
        if len(author_list) > 2:
            adj_matrix = adj_mat(g, author_list)
            diag_matrix = diag_mat(author_list, adj_matrix)
            arr = find_one_cluster(g, adj_matrix, diag_matrix, author_list)
            co_value = co_standard(g, arr, author_list)
            sum_value += co_value
            new_row = []

            if len(arr) > 2:  # 团队规模
                i = 0
                s1 = 0
                m = len(arr)
                while i < m:
                    q = i + 1
                    while q < m:
                        w = q + 1
                        while w < m:
                            if adj_matrix[arr[i]][arr[q]] != 0 and adj_matrix[arr[i]][arr[w]] != 0 and adj_matrix[arr[q]][arr[w]] != 0:
                                s1 += 1
                            w += 1
                        q += 1
                    i += 1
                new_row.append(len(arr))
                new_row.append(s1)
                #new_row.append(hindex(r'D:\aps\all_information.csv', arr, author_list))
                new_row.append(prim_vari(diag_matrix, arr))
                new_row.append(co_value)
                new_row.append(qtt(r'D:\aps\allauthors.csv', arr, author_list))
                csv_row.append(new_row)
                for name in g.nodes():
                    if name in arr:
                        print author_list.index(name)
                        c_index = g_num % 6
                        nd_colors[author_list.index(name)] = colors[c_index]
                print nd_colors
            g_num += 1
            #nx.draw_networkx_nodes(g,pos, author_list, node_color=nd_colors,node_size = 50)
            # nx.draw_networkx_labels(g,pos)
            # nx.draw_networkx_edges(g,pos)
            #nx.draw_random(g, with_labels=True,node_color=nd_colors)
            # plt.show()
    ave_co_value = sum_value / g_num
    print 'G has %d nodes and %d edges and %d subgraphs' % (G.number_of_nodes(), G.number_of_edges(), g_num)
    with open(r'D:\aps\all_clusters.csv', "w") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(csv_row)
    time2 = datetime.datetime.now()
    dura = (time2 - time1).seconds
    print "save all clusters finished"
    print "it cost %d seconds" % dura
    print "the co time value is %f" % ave_co_value
    # print index_dic
