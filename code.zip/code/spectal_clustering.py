import networkx as nx
import sys
import csv
import codecs
import numpy as np
from random import choice

reload(sys)
sys.setdefaultencoding("utf-8")


def GetGraph(filelist):
    for file in filelist:
        with open(file, "rb")as csvfile:
            reader = csv.reader(csvfile)
            for rows in reader:
                edge = [x for x in rows] + [1]
                edge = tuple(edge)
                edges.append(edge)

    G = nx.Graph()
    G.add_weighted_edges_from(edges)
    print G.number_of_nodes()
    return G


def Get_martix(G):
    for g in nx.connected_component(G):
      W = nx.to_numpy_matrix(g)


G = nx.Graph()
edges = [(1, 2, 1), (1, 7, 1), (1, 8, 1), (2, 3, 1), (2, 6, 1), (2, 8, 1), (2, 9, 1),
         (3, 4, 1), (3, 9, 1), (4, 5, 1), (4, 9, 1), (5, 6, 1), (5, 9, 1), (6, 7, 1), (7, 8, 1)]
G.add_weighted_edges_from(edges)
n = nx.number_of_nodes(G)
W = nx.to_numpy_matrix(G)
print W[0, 1]
# print W.shape()
D = np.matrix(np.zeros((n, n), dtype=np.int8))
sum_W = W.sum(axis=1)
print sum_W
for i in range(n - 1):
    D[i, i] = sum_W[i]
print D
